# Phone Number Location Tracker

## Overview
A Flask web application that allows users to track the geographic location of phone numbers. The app uses the OpenCage Geocoding API to find coordinates and generates interactive maps using Folium.

## Project Architecture
- **Backend**: Flask web server (Python 3.11)
- **Frontend**: HTML/CSS/JavaScript single-page application
- **Dependencies**: Flask, phonenumbers, opencage, folium
- **Package Management**: uv with pyproject.toml

## Features
- Parse phone numbers with country codes
- Identify phone carrier information
- Geocode location data using OpenCage API
- Generate interactive maps with Folium
- Responsive web interface

## Setup Status
- ✅ Dependencies installed with uv
- ✅ Flask web server configured on port 5000
- ✅ Web interface created with proper styling
- ✅ API endpoints working correctly
- ✅ Deployment configuration set to autoscale
- ✅ Static file serving configured

## Current State (September 16, 2025)
The application is fully functional and ready for use. The web server runs on localhost:5000 in development mode and is configured for deployment on Replit.

## Recent Changes
- Converted from command-line Python script to Flask web application
- Added responsive HTML interface with JavaScript
- Implemented error handling for invalid phone numbers
- Set up proper project structure with templates and static folders
- Configured deployment for Replit platform

## User Preferences
- Web interface preferred over command-line
- Visual map display for location results
- Error handling and user feedback