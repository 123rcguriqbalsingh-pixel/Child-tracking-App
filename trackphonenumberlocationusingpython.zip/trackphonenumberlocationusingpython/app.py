from flask import Flask, render_template, request, jsonify, send_file
import phonenumbers
from phonenumbers import geocoder, carrier
import folium
import os
from opencage.geocoder import OpenCageGeocode

app = Flask(__name__)

# OpenCage API key
OPENCAGE_KEY = "6d6f969fd9024ac8afde957f0c86a5ba"

def get_phone_location(phone_number):
    """Get location information for a phone number"""
    try:
        # Parse the phone number
        parsed_number = phonenumbers.parse(phone_number)
        
        # Get location description
        location = geocoder.description_for_number(parsed_number, "en")
        
        # Get carrier information with better error handling and validation
        try:
            # Parse the number again to ensure it's valid for carrier lookup
            check_validity = phonenumbers.is_valid_number(parsed_number)
            if check_validity:
                carrier_name = carrier.name_for_number(parsed_number, "en")
                # Clean up carrier name and handle empty results
                if carrier_name:
                    carrier_name = carrier_name.strip()
                    if carrier_name == "":
                        carrier_name = "Unknown"
                else:
                    carrier_name = "Unknown"
            else:
                carrier_name = "Invalid Number"
        except Exception as e:
            print(f"Carrier detection error: {e}")
            carrier_name = "Unknown"
        
        # Get coordinates using OpenCage geocoder
        geocoder_client = OpenCageGeocode(OPENCAGE_KEY)
        results = geocoder_client.geocode(str(location))
        
        if results and len(results) > 0:
            lat = results[0]['geometry']['lat']
            lng = results[0]['geometry']['lng']
            
            # Extract detailed location components
            components = results[0].get('components', {})
            state = components.get('state') or components.get('state_district') or components.get('county') or 'Unknown'
            country = components.get('country', 'Unknown')
            city = components.get('city') or components.get('town') or components.get('village') or 'Unknown'
            
            # Create enhanced popup text
            popup_text = f"{location}\\nPhone: {phone_number}\\nCarrier: {carrier_name}\\nState: {state}\\nCountry: {country}"
            
            # Create map
            map_location = folium.Map(location=[lat, lng], zoom_start=9)
            folium.Marker([lat, lng], popup=popup_text).add_to(map_location)
            
            # Save map to static folder
            map_path = "static/phone_location_map.html"
            os.makedirs("static", exist_ok=True)
            map_location.save(map_path)
            
            return {
                'success': True,
                'phone_number': phone_number,
                'location': location,
                'state': state,
                'country': country,
                'city': city,
                'carrier': carrier_name,
                'latitude': lat,
                'longitude': lng,
                'map_file': map_path
            }
        else:
            return {
                'success': False,
                'error': 'Could not find geographic coordinates for this location'
            }
            
    except Exception as e:
        return {
            'success': False,
            'error': f'Error processing phone number: {str(e)}'
        }

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/track', methods=['POST'])
def track_phone():
    phone_number = request.json.get('phone_number', '').strip()
    
    if not phone_number:
        return jsonify({'success': False, 'error': 'Please enter a phone number'})
    
    result = get_phone_location(phone_number)
    return jsonify(result)

@app.route('/map')
def view_map():
    map_path = "static/phone_location_map.html"
    if os.path.exists(map_path):
        return send_file(map_path)
    else:
        return "No map available. Please track a phone number first.", 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)